def mod1_func1():
    print("I am func1 of mod1")
    

