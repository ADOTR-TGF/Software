(C) Bridgeport Instruments, LLC, 2021-09-23
This set of examples shows how to access the custom features of the TGF firmware.
This firmware requires non-standard usbBases with a larger than normal FPGA, 
loaded with the TGF firmware.
The customization number for this firmware is 21505.
